<?php
/**
 * Redirect to the status.php page
 *
 * @author Sam
 */

require "WEB-INF/php/inc.php";

redirect("status.php");
?>
